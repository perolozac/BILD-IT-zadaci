package zadaci_09_02_2017;

import java.util.Scanner;

public class ZadatakBr2 {
	// 2. Napisati metodu koja prima jedan argument, broj pitanja, te generi�e
	// toliko nasumi�nih, jednostavnih pitanja oduzimanja tipa : �Koliko je 5 -
	// 2 ?�. Metoda treba da broji broj ta�nih i neta�nih odgovora te ih ispi�e
	// korisniku.
	public static void main(String[] args) {
		//objekat skener kako bih korsniku omogucili unos iz konzole
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite broj pitanja:");
		int brojPitanja = unos.nextInt();
		miniKviz(brojPitanja); // pozivamo metodu i prosledjujemo joj argument(broj pitanj)
		unos.close();
	}
                   //metoda
	public static void miniKviz(int brPitanja) {
		Scanner unos = new Scanner(System.in);
		int brTacnihOdgovora = 0;  //brojac tacnih odgovora
		for (int i = 0; i < brPitanja; i++) { 
			int x = (int) (1 + Math.random() * 10); //nasumicni brojevi
			int y = (int) (1 + Math.random() * 10);
			if (x < y) { //ako je prvi nasum.br. manji od prvog mjenjamo im mjesta
				int temp = x;
				x = y;
				y = temp;
			}
			System.out.print("Koliko iznosi " + x + "-" + y + "?");
			int rezultat = x - y;
			int odgovor = unos.nextInt();
			if (rezultat == odgovor) {
				brTacnihOdgovora++;
			}
		}
		System.out.println("Broj ta�nih odgovora: " + brTacnihOdgovora);
		System.out.println("Broj neta�nih odgovora: "
				+ (brPitanja - brTacnihOdgovora));
		unos.close();
	}
}
