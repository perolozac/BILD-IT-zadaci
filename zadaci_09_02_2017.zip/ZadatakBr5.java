package zadaci_09_02_2017;

import java.util.Scanner;

public class ZadatakBr5 {
	/*
	 * 5. Napisati metodu koja prima jedan argument te simulira bacanje nov�i�a
	 * toliko puta. Nakon �to se simulacija zavr�i, program ispisuje koliko puta
	 * je nov�i� pokazao glavu a koliko puta pismo.
	 */
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out
				.println("Unesite broj, koliko puta zelite da porogram simulira bacanje nov�i�a");
		// omogucujemo korisniku da unese iz konzole broj bacanja
		int brojBacanja = unos.nextInt();
		// pozivamo metodu i prsledjujemo joj korisnikov unos(argumenat)
		glavaPismo(brojBacanja);
	}

	// metoda za ispis i racunanje, koja prima jedan parametar
	public static void glavaPismo(int brojBacanja) {

		int pismo = 0; //brojac koliko je puta palo pismo
		for (int i = 0; i < brojBacanja; i++) { 
			
			
			//vrjednost varijable "broj" je uvjek  1 ili 0
			int broj = (int) (Math.round(Math.random()));
//ako je 0 , onda je pismo
			if (broj == 0) {
				pismo++;// brojimo koliko je puta bilo pismo
				System.out.println("pismo"); 
			} else
				System.out.println("glava");
		}
		//ispis rezultata
		System.out.println("\npismo je bilo " + pismo + " puta.");
		System.out.println("glava je bila " + (brojBacanja - pismo) + " puta.");

	}
}